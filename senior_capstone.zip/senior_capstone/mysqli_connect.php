<?php
$dbc = mysqli_connect('localhost','infost490s2404','mk828VvH*z','infost490s2404_gratify') OR die ('Could not connect to MySQL:'. mysqli_connect_error());

mysqli_set_charset($dbc, "utf8");
?>